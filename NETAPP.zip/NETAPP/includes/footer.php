</body>

<footer id="sticky-footer" class="nav aqua-gradient py-4 font-weight-bold z-depth-1 py-4 bg-dark text-black-50">
	<div class="container text-center text-black">
		<div class="container">
			<div class="row">
				<div class="col-sm"> 
					<a href="adminLogin.php"> Admin Login Panel </a> <!--| <a href="msebLogin.php"> MSEB Login Panel </a>--></p>
				</div>
				<div class="col-sm">
					
				</div>
				<div class="col-sm">
					<p>Copyright &copy; 2019 - All Rights Reserved <br>
					Developed by <br>Mansi Wakodkar</a></p>
				</div>
			</div>
		</div>
	</div>

</footer>

<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.10/js/mdb.min.js"></script>

</html>