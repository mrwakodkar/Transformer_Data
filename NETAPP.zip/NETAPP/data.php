<?php
$url="https://thingspeak.com/channels/962789/feed.json";
$homepage = file_get_contents($url);
$json =json_decode($homepage,true);

$conn = mysqli_connect('localhost','root','','iicdc');
/*$t=$json['temperature'];
$v=$json['vibration'];
$h=$json['humidity'];
$g=$json['Gas_sensor'];
$f=$json['IR_flame_sensor'];
echo "<br>temperature:".$t;
echo "<br>vibration:".$v;
echo "<br>humidity:".$h;
echo "<br>Gas sensor:".$g;
echo "<br>IR flame sensor:".$f;*/
//$c=$json['feeds'];
//print_r($c);
/*
foreach ($c as $key => $value) {
	$sql = "INSERT INTO sensors (temperature,vibration,humidity,gas,flame)VALUES (".$c[$key]['field1'].",".$c[$key]['field2'].",".$c[$key]['field3'].",".$c[$key]['field4'].",'".$c[$key]['field5']."')";
mysqli_query($conn,$sql);
}*/

$lastTime = "SELECT * FROM sensors ORDER BY id DESC LIMIT 1";

$result = mysqli_query($conn, $lastTime);
$lastRow = mysqli_fetch_assoc($result);
// print_r($lastRow['Time']);
$lastRecAt = $lastRow['Time'];

foreach($json['feeds'] as $entry){
	echo($lastRecAt);echo("<br>");echo(strtotime($lastRecAt));
	echo("<br>	");
	echo($entry["created_at"]);
	echo("<br>	");
	echo(strtotime($entry["created_at"]));
	echo("<br>	");

	if(strtotime($lastRecAt) < strtotime($entry["created_at"])){
		print_r($entry["field1"].'<br>');
		print_r($entry["field2"].'<br>');
	}
	echo ("====================================================<br>");
}



?>