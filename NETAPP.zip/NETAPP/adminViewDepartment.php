<?php
include './includes/header.php';

if(isset($_GET[delid]))
{
    $sql ="DELETE FROM TransformerInfo WHERE TransformerId='$_GET[delid]'";
    $qsql=mysqli_query($conn,$sql);
    if(mysqli_affected_rows($conn) == 1)
    {
        echo "<script>alert('department deleted successfully..');</script>";
    }
}
?>

<div class="container text-center">
    <br>
    <div class="row">
        <div class="col">
            <h2>View Transformer</h2></li></ul>
        </div>
        <div class="col">
            <h4>Search Transformer <input type="search" class="light-table-filter" data-table="order-table" placeholder="Filtrer" /></h4>
        </div>
    </div>
    <br>
    <div class="container">
        <section class="container">


            <table class="table table-striped">
                <thead class="purple-gradient white-text">
                    <tr>
                        <th width="33%">TransformerId</th>
                        <th width="33%">DeviceId</th>
                        <th width="33%">RegionAddress</th>
                        <th width="33%">TimeIntervals(min)</th>
                        <th width="33%">Email(ALERT)</th>
                        <th width="33%">Status</th>

                        <!--<th width="25$">Action</th>-->
                    </tr>
                </thead> 
                <tbody>

                    <?php
                    $sql ="SELECT * FROM TransformerInfo";
                    $qsql = mysqli_query($conn,$sql);
                    while($rs = mysqli_fetch_array($qsql))
                    {
                        echo "<tr>
                        <td>$rs[TransformerId]</td>
                        <td>$rs[DeviceID]</td>
                        <td>$rs[RegionAddress]</td>
                        <td>$rs[TimeIntervals]</td>

                        <td>$rs[Email]</td>
                        <td>$rs[status]</td>
                        <!--<td>
                        <a class=\"btn purple-gradient\" href='department.php?editid=$rs[TransformerId]'>Edit</a>  <a class=\"btn purple-gradient\"  href='viewdepartment.php?delid=$rs[TransformerId]'>Delete</a> </td>-->
                        </tr>";
                    }
                    ?>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </section>
    </div>
</div>

<?php
include './includes/footer.php';
?>