import pymysql
db = pymysql.connect("185.27.134.10","epiz_25052405","iamgroot:","epiz_25052405_warehouses" )

cursor = db.cursor()

cursor.execute("SELECT VERSION()")

data = cursor.fetchone()
print ("Database version : %s " % data)


db.close()