import pandas as pd
import numpy as np
import matplotlib.pylab as plt
import os

os.chdir("/var/www/html/python/End")
df = pd.read_csv('GlobalLandTemperaturesByCountry.csv', delimiter=',')

df.head(10)
type(df)
df.describe()

df_country = df.Country.unique()
len(df_country)

df_Germany = df.drop('AverageTemperatureUncertainty', axis=1)
df_Germany = df_Germany[df_Germany.Country == "India"]
df_Germany


df_Germany = df_Germany.drop('Country',axis=1)
df_Germany


df_Germany.index = pd.to_datetime(df_Germany.dt)
df_Germany


df_Germany = df_Germany.drop('dt', axis=1)
df_Germany


# Filtering data starting from 1970-01-01
df_Germany = df_Germany.loc['1970-01-01':]
df_Germany.head()


# Testing whether there are null values
df_Germany[df_Germany.isnull()]
len(df_Germany[df_Germany.isnull()])
df_Germany = df_Germany.sort_index()
df_Germany.index


# Replacing NaN values with the previous effective data
df_Germany.AverageTemperature.fillna(method='pad', inplace=True)
df_Germany[df_Germany.AverageTemperature.isnull()]


df_Germany.describe()


df_Germany['Ticks'] = range(0,len(df_Germany.index.values))
df_Germany.head(10)
df_Germany.tail(10)


#very simple plotting
fig = plt.figure(1)
ax1 = fig.add_subplot(111)
ax1.set_xlabel('Ticks')
ax1.set_ylabel('Avg. Temp.')
ax1.set_title('Original Plot')
ax1.plot('Ticks', 'AverageTemperature', data = df_Germany);


df_Germany




from statsmodels.tsa.stattools import adfuller
def stationarity_check(ts):
    
    # Determing rolling statistics
    roll_mean = pd.rolling_mean(ts, window=12)
    # Plot rolling statistics:
    plt.plot(ts, color='green',label='Original')
    plt.plot(roll_mean, color='blue', label='Rolling Mean')
    plt.legend(loc='best')
    plt.title('Rolling Mean')
    plt.show(block=False)
    
    # Perform Augmented Dickey-Fuller test:
    print('Augmented Dickey-Fuller test:')
    df_test = adfuller(ts)
    print("type of df_test: ",type(df_test))
    print("df_test: ",df_test)
    df_output = pd.Series(df_test[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    print("df_output: \n",df_output)
    for key,value in df_test[4].items():
        df_output['Critical Value (%s)'%key] = value
    print(df_output)
    
    

stationarity_check(df_Germany.AverageTemperature)



df_Germany['Roll_Mean'] = pd.rolling_mean(df_Germany.AverageTemperature, window=12)


df_Germany.pd.rolling_mean(df_Germany.AverageTemperature, window=12)
df_Germany.head(40)


from statsmodels.graphics.tsaplots import plot_pacf,plot_acf
plot_acf(df_Germany.AverageTemperature, lags=50)
plot_pacf(df_Germany.AverageTemperature, lags=50)
plt.xlabel('lags')
plt.show()




from statsmodels.tsa.arima_model import ARMA

import itertools
p = q = range(0, 4)
pq = itertools.product(p, q)
for param in pq:
    try:
        mod = ARMA(df_Germany.AverageTemperature,order=param)
        results = mod.fit()
        print('ARMA{} - AIC:{}'.format(param, results.aic))
    except:
        continue
    
    
    
model = ARMA(df_Germany.AverageTemperature, order=(2,3))  
results_MA = model.fit()  
plt.plot(df_Germany.AverageTemperature)
plt.plot(results_MA.fittedvalues, color='red')
plt.title('Fitting data _ MSE: %.2f'% (((results_MA.fittedvalues-df_Germany.AverageTemperature)**2).mean()))
plt.show()



predictions = results_MA.predict('01/01/1970', '12/01/2023')
predictions

