import pandas as pd
import numpy as np
import matplotlib.pylab as plt
import os

os.chdir("/home/skystone/Documents/sih/End-to-End-Data-Science-Project-Time-Series-Analysis-for-Temperature-Forecasting-using-ARIMA-Model")
df = pd.read_csv('GlobalLandTemperaturesByCountry.csv', delimiter=',')

df.head(10)
type(df)
df.describe()

df_country = df.Country.unique()
len(df_country)

dfIndia = df.drop('AverageTemperatureUncertainty', axis=1)
dfIndia = dfIndia[dfIndia.Country == "India"]
dfIndia


dfIndia = dfIndia.drop('Country',axis=1)
dfIndia


dfIndia.index = pd.to_datetime(dfIndia.dt)
dfIndia


dfIndia = dfIndia.drop('dt', axis=1)
dfIndia


# Filtering data starting from 1970-01-01
dfIndia = dfIndia.loc['1970-01-01':]
dfIndia.head()


# Testing whether there are null values
dfIndia[dfIndia.isnull()]
len(dfIndia[dfIndia.isnull()])
dfIndia = dfIndia.sort_index()
dfIndia.index


# Replacing NaN values with the previous effective data
dfIndia.AverageTemperature.fillna(method='pad', inplace=True)
dfIndia[dfIndia.AverageTemperature.isnull()]


dfIndia.describe()


dfIndia['Ticks'] = range(0,len(dfIndia.index.values))
dfIndia.head(10)
dfIndia.tail(10)


#very simple plotting
fig = plt.figure(1)
ax1 = fig.add_subplot(111)
ax1.set_xlabel('Ticks')
ax1.set_ylabel('Avg. Temp.')
ax1.set_title('Original Plot')
ax1.plot('Ticks', 'AverageTemperature', data = dfIndia);


dfIndia


from statsmodels.tsa.stattools import adfuller
def stationarity_check(ts):    
    # Determing rolling statistics
    #roll_mean = pd.rolling_mean(ts, window=12)
    roll_mean = ts.rolling(12).mean()
    
    # Plot rolling statistics:
    plt.plot(ts, color='green',label='Original')
    plt.plot(roll_mean, color='blue', label='Rolling Mean')
    plt.legend(loc='best')
    plt.title('Rolling Mean')
    plt.show(block=False)
    
    # Perform Augmented Dickey-Fuller test:
    print('Augmented Dickey-Fuller test:')
    df_test = adfuller(ts)
    print("type of df_test: ",type(df_test))
    print("df_test: ",df_test)
    df_output = pd.Series(df_test[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    print("df_output: \n",df_output)
    for key,value in df_test[4].items():
        df_output['Critical Value (%s)'%key] = value
    print(df_output)
    
    

stationarity_check(dfIndia.AverageTemperature)



#dfIndia['Roll_Mean'] = pd.rolling_mean(dfIndia.AverageTemperature, window=12)
dfIndia['Roll_Mean'] = dfIndia.AverageTemperature.rolling(12).mean()


dfIndia.pd.rolling_mean(dfIndia.AverageTemperature, window=12)
dfIndia.head(40)


from statsmodels.graphics.tsaplots import plot_pacf,plot_acf
plot_acf(dfIndia.AverageTemperature, lags=50)
plot_pacf(dfIndia.AverageTemperature, lags=50)
plt.xlabel('lags')
plt.show()




from statsmodels.tsa.arima_model import ARMA

import itertools
p = q = range(0, 4)
pq = itertools.product(p, q)
for param in pq:
    try:
        mod = ARMA(dfIndia.AverageTemperature,order=param)
        results = mod.fit()
        print('ARMA{} - AIC:{}'.format(param, results.aic))
    except:
        continue
    
    
    
model = ARMA(dfIndia.AverageTemperature, order=(2,3))  
results_MA = model.fit()  
plt.plot(dfIndia.AverageTemperature)
plt.plot(results_MA.fittedvalues, color='red')
plt.title('Fitting data _ MSE: %.2f'% (((results_MA.fittedvalues-dfIndia.AverageTemperature)**2).mean()))
plt.show()



predictions = results_MA.predict('01/01/1970', '12/01/2023')
print(predictions)

