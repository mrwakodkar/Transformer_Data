print("akshay")
from sklearn.externals import joblib 
print("adi")
# Load the model from the file 
tsModel = joblib.load('model.pkl') 

# Use the loaded model to make predictions 
print(tsModel.predict("1996-11-01 22:00:00","1996-11-03 04:00:00")) 


