<?php
include './includes/header.php';

if(isset($_GET[delid]))
{
    $sql ="DELETE FROM medicine WHERE medicineid='$_GET[delid]'";
    $qsql=mysqli_query($conn,$sql);
    if(mysqli_affected_rows($conn) == 1)
    {
        echo "<script>alert('Medicine redcord deleted successfully..');</script>";
    }
}
?>

<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <h2>View  medicine list</h2>
        </div>
        <div class="col">
            <h4>Search medicine - <input type="search" class="light-table-filter" data-table="order-table" placeholder="Filtrer" /></h4>
        </div>
    </div>
    <div class="container text-center">

        <section class="container">

            <br>
            <table class="table table-striped">
            <col>
                <colgroup span="2"></colgroup>
                <colgroup span="2"></colgroup>
                <thead class="purple-gradient white-text">
               
                        <tr>
                        <td rowspan="2"></td>
                        
                     
                        
                        <th colspan="3" scope="colgroup">VOLTAGE</th>
                        <th colspan="3" scope="colgroup">CURRENT</th>
                        <th colspan="3" scope="colgroup">POWER</th>
                        <th>OIL TEMPRATURE</th>
                        <th>OIL LEVEL</th>
                        <th>WINDING TEMP</th>
                        </tr>
                        <tr>
                            <th scope="col">VL1</th>
                            <th scope="col">VL2</th>
                            <th scope="col">VL3</th>
                            <th scope="col">IL1</th>
                            <th scope="col">IL2</th>
                            <th scope="col">IL3</th>
                            <th scope="col">WL1</th>
                            <th scope="col">WL2</th>
                            <th scope="col">WL3</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                            <th scope="col"></th>

                        </tr>
                        <!--
                        <th>VL1</th>
                        <th>VL2</th>
                        <th>VL3</th>
                        </th>
                        <th>IL1</th>
                        <th>IL2</th>
                        <th>IL3</th>
                        <th>WL1</th>
                        <th>WL2</th>
                        <th>WL3</th>
                        -->
                      
                     
                        
                    </tr>
                </thead> 
                <tbody>

                    <?php
                    $sql ="SELECT Overview.DeviceTimeStamp,Overview.OTI ,Overview.OLI,Overview.WTI,CurrentVoltage.VL1,CurrentVoltage.VL2,CurrentVoltage.VL3,CurrentVoltage.IL1,CurrentVoltage.IL2,CurrentVoltage.IL3,Power.WL1,Power.WL2,Power.WL3 FROM `Overview` Overview INNER JOIN `Power` Power ON Overview.DeviceTimeStamp=Power.DeviceTimeStamp\n "

                    . "INNER JOIN `CurrentVoltage` CurrentVoltage ON CurrentVoltage.DeviceTimeStamp=Power.DeviceTimeStamp";
                    $qsql = mysqli_query($conn,$sql);
                    while($rs = mysqli_fetch_array($qsql))
                    {
                        echo "<tr>
                        <td scope=\"row\" >$rs[DeviceTimeStamp]</td>
                        
                    
                        <td >$rs[VL1]</td>
                        <td >$rs[VL2]</td>
                        <td >$rs[VL3]</td>
                    
                        <td >$rs[IL1]</td>
                        <td >$rs[IL2]</td>
                        <td >$rs[IL3]</td>
                        <td >$rs[WL1]</td>
                        <td >$rs[WL2]</td>
                        <td >$rs[WL3]</td>
                        <td >$rs[OTI]</td>
                        <td >$rs[OLI]</td>
                        <td >$rs[WTI]</td>
                        <!--<td width=\"40%\">
                       <a class=\"btn purple-gradient\" href='medicine.php?editid=$rs[medicineid]'>Edit</a> <a class=\"btn purple-gradient\" href='viewmedicine.php?delid=$rs[medicineid]'>Delete</a> </td>-->
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </div>
</div>

<?php
include './includes/footer.php';
?>