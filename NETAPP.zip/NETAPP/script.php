<?php
	echo 'hi<br>';   
    print_r(shell_exec("python3 /opt/lampp/htdocs/warehouse-data-logging-website-sih/python/testTempHour1.py"));
?>
